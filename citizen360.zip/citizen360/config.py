"""
citizen360 — application config
Reads from environment variables / .env file via pydantic-settings.
"""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    OLLAMA_BASE_URL: str = "http://localhost:11434"
    OLLAMA_MODEL: str = "qwen3.5:2b-mlx"
    OLLAMA_TEMPERATURE: float = 0.0

    MILVUS_DB_PATH: str = "./milvus_lite.db"
    # Single collection with two named partitions — mirrors Student Dropout v1.3.1
    # schema_store    → table YAML descriptions (index_tables.py)
    # few_shot_store  → NL→SQL fewshot examples (index_examples.py)
    MILVUS_COLLECTION: str = "schema_index"
    # Legacy aliases kept for backward compatibility
    MILVUS_COLLECTION_SQL_EXAMPLES: str = "schema_index"
    MILVUS_COLLECTION_TABLES: str = "schema_index"

    EMBEDDING_MODEL: str = "nomic-embed-text"

    TOP_K_SQL_EXAMPLES: int = 5
    TOP_K_CANDIDATE_TABLES: int = 10

    LOG_LEVEL: str = "INFO"


settings = Settings()
