"""
citizen360.plugins.vector.base
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Abstract vector store interface + module-level registry.
"""
from __future__ import annotations

import abc
from typing import Callable, Type


class VectorStore(abc.ABC):
    """
    Abstract base class for all vector store backends.

    All methods are async to support remote stores (Milvus Standalone, etc.)
    without changing the interface.
    """

    @abc.abstractmethod
    async def search(
        self,
        collection: str,
        query_embedding: list[float],
        top_k: int,
        filter: dict | None = None,
    ) -> list[dict]:
        """
        ANN search in *collection*.

        :param collection:      Collection / namespace name.
        :param query_embedding: Dense query vector.
        :param top_k:           Maximum number of results to return.
        :param filter:          Optional metadata filter, e.g. ``{"workspace_id": "school"}``.
        :returns: List of result dicts containing at least the stored fields + ``score``.
        """

    @abc.abstractmethod
    async def upsert(self, collection: str, records: list[dict]) -> None:
        """
        Insert or update *records* in *collection*.

        Each record dict must contain an ``embedding`` key with the dense vector
        plus any scalar fields defined in the collection schema.

        :param collection: Collection name.
        :param records:    List of record dicts.
        """

    @abc.abstractmethod
    async def ensure_collection(self, collection: str, dim: int) -> None:
        """
        Create the collection if it does not already exist.

        :param collection: Collection name.
        :param dim:        Embedding dimension.
        """


# ── Module-level registry ──────────────────────────────────────────────────────

VECTOR_REGISTRY: dict[str, Type[VectorStore]] = {}


def register_vector(name: str) -> Callable[[Type[VectorStore]], Type[VectorStore]]:
    """
    Class decorator that registers a concrete :class:`VectorStore` by *name*.

    Usage::

        @register_vector("milvus_lite")
        class MilvusLiteStore(VectorStore):
            ...
    """
    def decorator(cls: Type[VectorStore]) -> Type[VectorStore]:
        VECTOR_REGISTRY[name] = cls
        return cls
    return decorator
