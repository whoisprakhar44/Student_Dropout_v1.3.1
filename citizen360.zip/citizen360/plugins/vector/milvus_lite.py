"""
citizen360.plugins.vector.milvus_lite
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Concrete VectorStore backed by Milvus-Lite (pymilvus MilvusClient).

Architecture — matches Student Dropout v1.3.1 exactly
-------------------------------------------------------
Single Milvus collection with TWO named partitions:

  schema_store    — one record per table YAML (indexed by index_tables.py)
  few_shot_store  — NL→SQL exemplars         (indexed by index_examples.py)

Field mapping per partition  (same schema for both — keeps things DRY):
  Partition        embedding_text       raw_ddl       table_name    database_name
  ─────────────    ──────────────       ───────       ──────────    ─────────────
  schema_store     rich YAML prose      DDL string    table name    DB name
  few_shot_store   NL question          gold SQL      intent        use_case

Additional citizen360-specific field (not in Student Dropout — needed because
citizen360 is multi-workspace):
  workspace_id  VARCHAR(64)   — "school" | "canonical_model" | "misc"

Why single collection + partitions instead of two separate collections?
  • A single FLAT index covers all vectors — no duplicated index cost.
  • At query time scope to one partition OR search both at once.
  • Identical schema across partitions keeps the code DRY.
  (This is exactly the reasoning stated in Student Dropout's pipeline.py.)

Both partitions use FLAT index with metric_type=COSINE.
"""
from __future__ import annotations

import logging
import uuid
from typing import Any

from pymilvus import MilvusClient, DataType

from citizen360.plugins.vector.base import VectorStore, register_vector

logger = logging.getLogger(__name__)

# ── Partition names (identical to Student Dropout) ────────────────────────────
PARTITION_SCHEMA   = "schema_store"
PARTITION_FEW_SHOT = "few_shot_store"

# Fixed embedding dimension for nomic-embed-text
_DIM = 768


@register_vector("milvus_lite")
class MilvusLiteStore(VectorStore):
    """
    Milvus-Lite-backed vector store.

    Single collection, two named partitions — mirrors Student Dropout v1.3.1.

    :param db_path:     Path to the Milvus-Lite .db file.
    :param collection:  Collection name (default: ``schema_index``).
    :param metric_type: Distance metric (default: ``COSINE``).
    """

    def __init__(
        self,
        db_path: str = "./milvus_lite.db",
        collection: str = "schema_index",
        metric_type: str = "COSINE",
        # Legacy compat — old code passes sql_col / tables_col; ignore them
        sql_col: str | None = None,
        tables_col: str | None = None,
    ) -> None:
        self._client     = MilvusClient(uri=db_path)
        self._collection = collection
        self._metric     = metric_type

    # ── Internal helpers ───────────────────────────────────────────────────────

    def _build_schema(self, dim: int):
        """
        7-field schema — identical to Student Dropout pipeline.py.
        + workspace_id (citizen360 multi-workspace extension).
        """
        schema = MilvusClient.create_schema(
            auto_id=False,
            enable_dynamic_field=False,
        )
        schema.add_field("id",             DataType.VARCHAR, is_primary=True, max_length=64)
        schema.add_field("database_name",  DataType.VARCHAR, max_length=256)
        schema.add_field("table_name",     DataType.VARCHAR, max_length=256)
        schema.add_field("embedding_text", DataType.VARCHAR, max_length=10000)
        schema.add_field("raw_ddl",        DataType.VARCHAR, max_length=65535)
        schema.add_field("source_file",    DataType.VARCHAR, max_length=512)
        schema.add_field("workspace_id",   DataType.VARCHAR, max_length=64)
        schema.add_field("embedding",      DataType.FLOAT_VECTOR, dim=dim)
        return schema

    def _build_index_params(self):
        """FLAT index on embedding with COSINE metric — same as Student Dropout."""
        index_params = MilvusClient.prepare_index_params()
        index_params.add_index(
            field_name="embedding",
            index_type="FLAT",
            metric_type=self._metric,
        )
        return index_params

    def _ensure_partitions(self):
        """Idempotently create both partitions — mirrors Student Dropout."""
        for part in (PARTITION_SCHEMA, PARTITION_FEW_SHOT):
            if not self._client.has_partition(
                collection_name=self._collection,
                partition_name=part,
            ):
                self._client.create_partition(
                    collection_name=self._collection,
                    partition_name=part,
                )

    # ── Public interface ───────────────────────────────────────────────────────

    async def initialize(self, dim: int = _DIM) -> None:
        """
        Ensure the collection + both partitions exist, then load into memory.
        Call once at application startup.
        """
        if self._client.has_collection(self._collection):
            logger.debug("Collection '%s' exists — ensuring partitions.", self._collection)
            self._ensure_partitions()
        else:
            logger.info(
                "Creating Milvus-Lite collection '%s' (dim=%d, metric=%s).",
                self._collection, dim, self._metric,
            )
            schema       = self._build_schema(dim)
            index_params = self._build_index_params()
            self._client.create_collection(
                collection_name=self._collection,
                schema=schema,
                index_params=index_params,
            )
            self._ensure_partitions()

        try:
            self._client.load_collection(self._collection)
        except Exception as exc:
            logger.debug("load_collection('%s') skipped: %s", self._collection, exc)

    def drop_collection(self) -> None:
        """Drop the whole collection (used during re-indexing)."""
        if self._client.has_collection(self._collection):
            logger.info("Dropping Milvus collection '%s'.", self._collection)
            self._client.drop_collection(self._collection)

    def insert(
        self,
        records: list[dict],
        partition: str = PARTITION_SCHEMA,
    ) -> None:
        """
        Insert records into a named partition.

        Each record must have the 7 core fields + embedding:
            id, database_name, table_name, embedding_text,
            raw_ddl, source_file, workspace_id, embedding
        """
        if not records:
            return
        data = [
            {
                "id":             r.get("id", str(uuid.uuid4())),
                "database_name":  r.get("database_name", ""),
                "table_name":     r.get("table_name", ""),
                "embedding_text": r.get("embedding_text", "")[:10000],
                "raw_ddl":        r.get("raw_ddl", "")[:65535],
                "source_file":    r.get("source_file", ""),
                "workspace_id":   r.get("workspace_id", ""),
                "embedding":      r["embedding"],
            }
            for r in records
        ]
        logger.info(
            "Inserting %d records into '%s' / partition='%s'.",
            len(data), self._collection, partition,
        )
        self._client.upsert(
            collection_name=self._collection,
            partition_name=partition,
            data=data,
        )

    # Legacy compat — old nodes call upsert(); forward to insert()
    async def upsert(self, collection: str, records: list[dict]) -> None:
        partition = PARTITION_FEW_SHOT if collection.startswith("sql") else PARTITION_SCHEMA
        self.insert(records, partition=partition)

    async def search(
        self,
        collection: str,
        query_embedding: list[float],
        top_k: int,
        filter: dict | None = None,
        partition: str | None = None,
    ) -> list[dict]:
        """
        ANN search — mirrors Student Dropout's _query_milvus().

        :param partition: Optional partition scope. None = search all partitions.
        :param filter:    Dict of field→value equality filters (workspace_id etc).
        :returns: List of dicts with table_name, database_name, raw_ddl,
                  embedding_text, workspace_id, score.
        """
        # Build optional filter expression
        filter_expr: str | None = None
        if filter:
            clauses = [f'{k} == "{v}"' for k, v in filter.items()]
            filter_expr = " and ".join(clauses)

        kwargs: dict[str, Any] = {
            "collection_name": self._collection,
            "data":            [query_embedding],
            "limit":           top_k,
            "output_fields":   [
                "table_name", "database_name",
                "raw_ddl", "embedding_text", "workspace_id", "source_file",
            ],
            "search_params": {"metric_type": self._metric},
        }
        if partition:
            kwargs["partition_names"] = [partition]
        if filter_expr:
            kwargs["filter"] = filter_expr

        logger.debug(
            "Milvus search collection=%s partition=%s top_k=%d filter=%s",
            self._collection, partition, top_k, filter_expr,
        )

        try:
            results = self._client.search(**kwargs)
        except Exception as exc:
            if "released" in str(exc).lower():
                logger.warning("Collection released — reloading and retrying.")
                self._client.load_collection(self._collection)
                results = self._client.search(**kwargs)
            else:
                raise

        hits: list[dict] = []
        for hit in results[0]:
            row = {
                "table_name":     hit["entity"].get("table_name", ""),
                "database_name":  hit["entity"].get("database_name", ""),
                "raw_ddl":        hit["entity"].get("raw_ddl", ""),
                "embedding_text": hit["entity"].get("embedding_text", ""),
                "workspace_id":   hit["entity"].get("workspace_id", ""),
                "source_file":    hit["entity"].get("source_file", ""),
                "score":          hit["distance"],
            }
            hits.append(row)
        return hits

    # ── Partition-scoped search helpers (used by rag_retrieval) ───────────────

    async def search_schema(
        self,
        query_embedding: list[float],
        top_k: int,
        workspace_id: str | None = None,
    ) -> list[dict]:
        """Search schema_store partition."""
        f = {"workspace_id": workspace_id} if workspace_id else None
        return await self.search(
            collection=self._collection,
            query_embedding=query_embedding,
            top_k=top_k,
            filter=f,
            partition=PARTITION_SCHEMA,
        )

    async def search_fewshots(
        self,
        query_embedding: list[float],
        top_k: int,
        workspace_id: str | None = None,
    ) -> list[dict]:
        """Search few_shot_store partition."""
        f = {"workspace_id": workspace_id} if workspace_id else None
        return await self.search(
            collection=self._collection,
            query_embedding=query_embedding,
            top_k=top_k,
            filter=f,
            partition=PARTITION_FEW_SHOT,
        )

    # ── Legacy: ensure_collection forwarded to initialize() ───────────────────
    async def ensure_collection(self, collection: str, dim: int = _DIM) -> None:
        await self.initialize(dim=dim)
