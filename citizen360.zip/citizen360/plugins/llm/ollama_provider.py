"""
citizen360.plugins.llm.ollama_provider
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Concrete LLM provider backed by the Ollama async SDK.
Uses Qwen2.5/Qwen3 (or any model configured via Settings).

Note on Qwen3 reasoning models:
  Qwen3 models have a built-in "think" mode that emits <think>...</think>
  blocks before the actual answer. When combined with Ollama's format="json",
  this can produce empty content (the model puts all output in the think block).
  We disable thinking via options={"think": False} and strip residual tags.
"""
from __future__ import annotations

import json
import logging
import re

import ollama

from citizen360.plugins.llm.base import LLMProvider, register_llm

logger = logging.getLogger(__name__)


@register_llm("ollama")
class OllamaProvider(LLMProvider):
    """
    Ollama-backed LLM provider.

    :param base_url:    Ollama server URL, e.g. ``http://localhost:11434``.
    :param model:       Chat/completion model name, e.g. ``qwen2.5``.
    :param embed_model: Embedding model name, e.g. ``nomic-embed-text``.
    :param temperature: Sampling temperature (0.0 = deterministic).
    """

    def __init__(
        self,
        base_url: str = "http://localhost:11434",
        model: str | None = None,
        embed_model: str = "nomic-embed-text",
        temperature: float = 0.0,
    ) -> None:
        from citizen360.config import settings
        self._client = ollama.AsyncClient(host=base_url)
        self._model = model or settings.OLLAMA_MODEL
        self._embed_model = embed_model
        self._temperature = temperature

    async def chat(
        self,
        system: str,
        user: str,
        json_mode: bool = False,
    ) -> str:
        """
        Single-turn chat via Ollama ``/api/chat``.

        When *json_mode* is True, sets ``format="json"`` so the model returns
        only valid JSON text (Ollama structured-output feature).
        """
        messages = [
            {"role": "system", "content": system},
            {"role": "user",   "content": user},
        ]
        # think=False disables the Qwen3 reasoning/chain-of-thought mode.
        # Without this, Qwen3 models emit <think>…</think> blocks which can
        # produce empty content when combined with format="json".
        kwargs: dict = {
            "model": self._model,
            "messages": messages,
            "options": {"temperature": self._temperature, "think": False},
            "stream": False,
        }
        if json_mode:
            kwargs["format"] = "json"

        logger.debug("OllamaProvider.chat model=%s json_mode=%s", self._model, json_mode)
        response = await self._client.chat(**kwargs)
        content: str = response["message"]["content"]

        # Defensive: strip any residual <think>...</think> blocks in case
        # an older Ollama version ignores the think=False option.
        content = re.sub(r"<think>.*?</think>", "", content, flags=re.DOTALL).strip()

        return content

    async def embed(self, text: str) -> list[float]:
        """
        Embed *text* using Ollama ``/api/embeddings``.
        """
        logger.debug("OllamaProvider.embed model=%s", self._embed_model)
        response = await self._client.embeddings(
            model=self._embed_model,
            prompt=text,
        )
        return response["embedding"]
