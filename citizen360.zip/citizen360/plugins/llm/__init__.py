"""citizen360.plugins.llm — LLM provider registry."""
from citizen360.plugins.llm.base import LLMProvider, LLM_REGISTRY, register_llm
from citizen360.plugins.llm.ollama_provider import OllamaProvider

__all__ = ["LLMProvider", "LLM_REGISTRY", "register_llm", "OllamaProvider"]
