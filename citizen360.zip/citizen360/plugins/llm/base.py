"""
citizen360.plugins.llm.base
~~~~~~~~~~~~~~~~~~~~~~~~~~~
Abstract LLM provider interface + module-level registry.
"""
from __future__ import annotations

import abc
from typing import Callable, Type


class LLMProvider(abc.ABC):
    """
    Abstract base class for all LLM providers.

    Subclasses must implement :meth:`chat` and :meth:`embed`.
    Register a concrete implementation with the :func:`register_llm` decorator.
    """

    @abc.abstractmethod
    async def chat(
        self,
        system: str,
        user: str,
        json_mode: bool = False,
    ) -> str:
        """
        Send a single-turn chat request.

        :param system: System prompt text.
        :param user:   User prompt text.
        :param json_mode: If True, instruct the model to return valid JSON only.
        :returns: Raw string response from the model.
        """

    @abc.abstractmethod
    async def embed(self, text: str) -> list[float]:
        """
        Embed *text* into a dense vector.

        :param text: Input text to embed.
        :returns: List of floats (embedding vector).
        """


# ── Module-level registry ──────────────────────────────────────────────────────

LLM_REGISTRY: dict[str, Type[LLMProvider]] = {}


def register_llm(name: str) -> Callable[[Type[LLMProvider]], Type[LLMProvider]]:
    """
    Class decorator that registers a concrete :class:`LLMProvider` by *name*.

    Usage::

        @register_llm("ollama")
        class OllamaProvider(LLMProvider):
            ...
    """
    def decorator(cls: Type[LLMProvider]) -> Type[LLMProvider]:
        LLM_REGISTRY[name] = cls
        return cls
    return decorator
