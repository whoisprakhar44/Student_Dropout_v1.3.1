"""
citizen360.plugins.workspace.school
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
School cluster — tables from schema/school/*.yaml

Cluster ID: "school"
Tables: 18 fact/dim tables covering student attendance, academic performance,
        infrastructure, mid-day meals, scheme benefits, and teacher attendance.
"""
from citizen360.plugins.workspace.base import WorkspaceDefinition

SchoolWorkspace = WorkspaceDefinition(
    id="school",
    display_name="School Data",
    # Auto-derived from schema/school/ — all 18 YAML stems
    candidate_tables=[
        "absent_reason_dim",
        "assessment_dim",
        "beneficiary_type_dim",
        "benefit_type_dim",
        "infrastructure_category_dim",
        "infrastructure_component_dim",
        "meal_type_dim",
        "mid_day_meal_serving_fact",
        "nutrition_item_dim",
        "scheme_benefits_fact",
        "school_academic_performance_fact",
        "school_infra_category_dim",
        "school_infra_component_dim",
        "school_infrastructure_progress_fact",
        "school_meal_menu_dim",
        "school_student_attendance_fact",
        "school_teacher_attendance_fact",
        "student_class_dim",
    ],
    business_glossary={
        "academic year": "period from June 1 to May 31",
        "dropout": "student with attendance < 30% for 3 consecutive months",
        "enrollment_status": "one of: ACTIVE, TRANSFERRED, DROPPED, GRADUATED",
        "present_flag": "Y/N flag — Y means student was present that day",
        "absent_flag": "Y/N flag — Y means student was absent that day",
        "attendance_weight": "decimal (0.0–1.0) representing partial/full attendance",
    },
    date_handling_notes=(
        "Academic year starts June 1. "
        "'Last year' means previous academic year, not calendar year. "
        "academic_year column stores single integer year (e.g. '2025' = 2025-26 session)."
    ),
    schema_dir="schema/school",
    cluster_keywords=[
        "school", "student", "attendance", "dropout", "grade", "class",
        "teacher", "meal", "scheme benefit", "infrastructure", "academic",
        "performance", "assessment", "nutrition",
    ],
)
