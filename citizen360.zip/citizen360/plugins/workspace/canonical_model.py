"""
citizen360.plugins.workspace.canonical_model
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Canonical data model cluster — citizen master data.
Tables from schema/canonicalmodel/*.yaml (37 tables).

Cluster ID: "canonical_model"
Covers: citizen identity, address, education, family, assets,
        land, health, welfare schemes, ration cards, bank accounts.
"""
from citizen360.plugins.workspace.base import WorkspaceDefinition

CanonicalModelWorkspace = WorkspaceDefinition(
    id="canonical_model",
    display_name="Canonical Data Model",
    candidate_tables=[
        "citizen_address_master",
        "citizen_address_master_test",
        "citizen_agriculture_land",
        "citizen_asset_electricity",
        "citizen_asset_vaahan",
        "citizen_asset_vaahan_type",
        "citizen_bank_accounts",
        "citizen_consent",
        "citizen_document",
        "citizen_document_testing",
        "citizen_education",
        "citizen_family_master",
        "citizen_health_schemes",
        "citizen_health_schemes_master",
        "citizen_idty",
        "citizen_idty_type",
        "citizen_land",
        "citizen_master",
        "citizen_property",
        "citizen_school",
        "citizen_school_teacher",
        "citizen_student",
        "citizen_utility_connection",
        "citizen_welfare_schemes",
        "citizen_welfare_schemes_master",
        "gsws_sec_secretariat_master",
        "health_scheme_code",
        "ration_card_citizen",
        "ration_card_citizen_reason",
        "ration_card_family",
        "ration_card_type",
        "school_category",
        "school_medium",
        "school_scheme_master",
        "school_subject_master",
        "source_department_code",
        "welfare_schemes_life_cycle",
    ],
    business_glossary={
        "citizen_master": "core identity record linking all citizen data",
        "ration_card": "government food subsidy entitlement document",
        "welfare_scheme": "government benefit program (health, education, housing)",
        "gsws": "Grama/Ward Sachivalayam — village-level government office",
    },
    date_handling_notes="Use ISO dates. No special fiscal calendar.",
    schema_dir="schema/canonicalmodel",
    cluster_keywords=[
        "citizen", "ration card", "welfare", "health scheme", "identity",
        "aadhaar", "family", "address", "land", "property", "vehicle",
        "bank account", "education", "document", "beneficiary",
    ],
)

