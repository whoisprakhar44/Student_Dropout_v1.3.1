"""
citizen360.plugins.workspace.misc
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Miscellaneous cluster — temple and sundry department tables.
Tables from schema/misc/*.yaml (3 tables).

Cluster ID: "misc"
"""
from citizen360.plugins.workspace.base import WorkspaceDefinition

MiscWorkspace = WorkspaceDefinition(
    id="misc",
    display_name="Miscellaneous (Temple / Other Departments)",
    candidate_tables=[
        "core_temple_auvs_summary_tab_test_dummy",
        "core_temple_ddns",
        "core_temple_ddrf_test_dummy",
    ],
    business_glossary={
        "auvs": "Andhra Pradesh Urban Voluntary Services",
        "ddns": "Devasthanam Department Name System",
    },
    date_handling_notes="Use ISO dates. No special fiscal calendar.",
    schema_dir="schema/misc",
    cluster_keywords=[
        "temple", "devasthanam", "auvs", "religious", "endowment",
    ],
)
