"""
citizen360.plugins.workspace.base
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Abstract workspace definition.

Each workspace maps to a cluster of tables from one YAML subfolder.
The cluster_keywords list is used by the intent agent to predict which
cluster a user query belongs to.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class WorkspaceDefinition:
    """
    Descriptor for a single analytics workspace / schema cluster.

    Fields
    ------
    id                Unique cluster identifier, e.g. "school"
    display_name      Human-readable name shown in prompts
    candidate_tables  All table names in this cluster (from YAML stems)
    business_glossary Domain-specific term → definition mapping
    date_handling_notes  Injected into LLM system prompt for date logic
    schema_dir        Relative path to YAML files, e.g. "schema/school"
    cluster_keywords  Keywords used to predict cluster from user prompt
    """

    id: str
    display_name: str
    candidate_tables: list[str] = field(default_factory=list)
    business_glossary: dict[str, str] = field(default_factory=dict)
    date_handling_notes: str = ""
    schema_dir: str = ""
    cluster_keywords: list[str] = field(default_factory=list)
