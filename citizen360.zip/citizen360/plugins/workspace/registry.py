"""
citizen360.plugins.workspace.registry
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
WorkspaceRegistry — discovers and indexes all workspace / cluster definitions.

Adding a new cluster
---------------------
1. Create schema/<cluster_id>/*.yaml files
2. Create plugins/workspace/<cluster_id>.py with a WorkspaceDefinition
3. Add ONE import + ONE entry in _WORKSPACES below
"""
from __future__ import annotations

import logging

from citizen360.plugins.workspace.base import WorkspaceDefinition

# ── All cluster definitions ────────────────────────────────────────────────────
from citizen360.plugins.workspace.school import SchoolWorkspace
from citizen360.plugins.workspace.canonical_model import CanonicalModelWorkspace
from citizen360.plugins.workspace.misc import MiscWorkspace

logger = logging.getLogger(__name__)

_WORKSPACES: list[WorkspaceDefinition] = [
    SchoolWorkspace,
    CanonicalModelWorkspace,
    MiscWorkspace,
]


class WorkspaceRegistry:
    """
    Indexed lookup of all registered workspace definitions.

    Instantiate once at application startup and inject into nodes.
    """

    def __init__(self) -> None:
        self._index: dict[str, WorkspaceDefinition] = {}
        for ws in _WORKSPACES:
            if ws.id in self._index:
                raise ValueError(f"Duplicate workspace id: {ws.id!r}")
            self._index[ws.id] = ws
        logger.info(
            "WorkspaceRegistry loaded %d workspace(s): %s",
            len(self._index),
            list(self._index),
        )

    def get(self, workspace_id: str) -> WorkspaceDefinition:
        """
        Return the :class:`WorkspaceDefinition` for *workspace_id*.

        :raises KeyError: if the workspace_id is not registered.
        """
        if workspace_id not in self._index:
            raise KeyError(f"Unknown workspace: {workspace_id!r}")
        return self._index[workspace_id]

    def list_ids(self) -> list[str]:
        """Return all registered workspace IDs."""
        return list(self._index.keys())

    def list_display_names(self) -> list[str]:
        """Return display names in the same order as :meth:`list_ids`."""
        return [ws.display_name for ws in self._index.values()]

    def format_for_prompt(self) -> str:
        """
        Format cluster list for injection into an LLM system prompt.

        Includes cluster keywords to help the LLM predict the right cluster.

        Example output::

            - school: School Data
              keywords: school, student, attendance, dropout, grade, class
            - canonical_model: Canonical Data Model
              keywords: citizen, ration card, welfare, health scheme, identity
        """
        lines = []
        for ws in self._index.values():
            lines.append(f"- {ws.id}: {ws.display_name}")
            if ws.cluster_keywords:
                kw = ", ".join(ws.cluster_keywords[:8])  # top 8 keywords
                lines.append(f"  keywords: {kw}")
        return "\n".join(lines)
