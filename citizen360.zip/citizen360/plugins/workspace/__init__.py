"""citizen360.plugins.workspace — workspace registry and cluster definitions."""
from citizen360.plugins.workspace.base import WorkspaceDefinition
from citizen360.plugins.workspace.school import SchoolWorkspace
from citizen360.plugins.workspace.canonical_model import CanonicalModelWorkspace
from citizen360.plugins.workspace.misc import MiscWorkspace
from citizen360.plugins.workspace.registry import WorkspaceRegistry

__all__ = [
    "WorkspaceDefinition",
    "SchoolWorkspace",
    "CanonicalModelWorkspace",
    "MiscWorkspace",
    "WorkspaceRegistry",
]
