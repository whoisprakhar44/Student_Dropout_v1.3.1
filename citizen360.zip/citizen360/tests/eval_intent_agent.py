"""
tests/eval_intent_agent.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~
Level 1 Classification Evaluation — Intent Agent Accuracy

Evaluates whether the intent agent correctly predicts the required workspaces (clusters)
for questions in the gold dataset.

A classification is correct if the predicted workspace_ids cover all workspaces
demanded by the gold tables.

How to run:
  python tests/eval_intent_agent.py
  pytest tests/eval_intent_agent.py -v -s
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path
from typing import Any

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT.parent))
sys.path.insert(0, str(ROOT))

from citizen360.nodes.intent_agent import intent_agent_node
from citizen360.plugins.llm.ollama_provider import OllamaProvider
from citizen360.plugins.workspace.registry import WorkspaceRegistry
from citizen360.config import settings

GOLD_PATH = ROOT / "data" / "gold_dataset.jsonl"


async def run_intent_eval(n: int | None = None, verbose: bool = True) -> float:
    """
    Run the intent agent on every gold question and evaluate classification accuracy.
    """
    if not GOLD_PATH.exists():
        raise FileNotFoundError(f"Gold dataset not found at {GOLD_PATH}")

    llm = OllamaProvider(
        base_url=settings.OLLAMA_BASE_URL,
        embed_model=settings.EMBEDDING_MODEL,
    )
    registry = WorkspaceRegistry()

    # Map tables to workspaces
    table_to_ws = {}
    for ws_id in registry.list_ids():
        for t in registry.get(ws_id).candidate_tables:
            table_to_ws[t] = ws_id

    gold_cases: list[dict] = []
    with GOLD_PATH.open() as f:
        for i, line in enumerate(f):
            if n and i >= n:
                break
            gold_cases.append(json.loads(line))

    print(f"\n{'═'*70}")
    print(f"  Intent Agent Classification Evaluation  |  {len(gold_cases)} questions")
    print(f"{'═'*70}\n")

    correct = 0
    total = len(gold_cases)
    misses = []

    for i, case in enumerate(gold_cases, 1):
        q = case["question"]
        gold_tables: list[str] = case["gold_tables"]
        gold_ws = set(table_to_ws.get(t) for t in gold_tables if table_to_ws.get(t))
        if not gold_ws:
            gold_ws = {case["workspace_id"]}

        state = {"raw_question": q}
        try:
            res = await intent_agent_node(state, llm=llm, workspace_registry=registry)
            pred_ws = set(res.get("workspace_ids", []))
        except Exception as exc:
            print(f"  [{i:03d}] LLM ERROR: {exc}")
            pred_ws = set()

        is_correct = gold_ws.issubset(pred_ws)
        if is_correct:
            correct += 1
            if verbose:
                print(f"  ✓ [{i:03d}] MATCH  gold={sorted(list(gold_ws))}  pred={sorted(list(pred_ws))}  | {q[:50]}…")
        else:
            misses.append((i, q, gold_ws, pred_ws))
            print(f"  ✗ [{i:03d}] MISS   gold={sorted(list(gold_ws))}  pred={sorted(list(pred_ws))}  | {q[:50]}…")

    accuracy = correct / total if total > 0 else 0.0

    print(f"\n{'═'*70}")
    print(f"  CLASSIFICATION EVALUATION RESULTS")
    print(f"{'─'*70}")
    print(f"  Total Evaluated      : {total}")
    print(f"  Correct Predictions  : {correct}")
    print(f"  Accuracy             : {accuracy:.1%}")
    print(f"{'═'*70}\n")

    if misses:
        print("  Top Misses:")
        for idx, q, g, p in misses[:10]:
            print(f"    - [{idx:03d}] Q: {q}")
            print(f"            Gold: {sorted(list(g))}")
            print(f"            Pred: {sorted(list(p))}")
        print()

    return accuracy


@pytest.mark.asyncio
async def test_intent_accuracy_above_threshold():
    """Assert classification accuracy is at least 90%."""
    try:
        acc = await run_intent_eval(n=30, verbose=False)
    except FileNotFoundError as exc:
        pytest.skip(str(exc))
    except Exception as exc:
        pytest.skip(f"Ollama unavailable: {exc}")

    assert acc >= 0.90, f"Intent classification accuracy {acc:.1%} is below 90% threshold"


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Evaluate classification accuracy of the intent agent.")
    parser.add_argument("--n", type=int, default=None, help="Number of questions (default: all)")
    parser.add_argument("--quiet", action="store_true", help="Only print final summary")
    args = parser.parse_args()

    asyncio.run(run_intent_eval(n=args.n, verbose=not args.quiet))
