"""
tests/eval_retrieval_l2_ragas.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Level 2 Retrieval Evaluation — RAGAS Framework

Uses RAGAS ContextPrecision, ContextRecall, ContextEntityRecall.

How contexts are built
----------------------
Each retrieved TABLE NAME is mapped to the rich YAML description text
from schema/<cluster>/<table_name>.yaml. This text becomes the "context"
that RAGAS evaluates for relevance and coverage.

Gold contexts (reference) = YAML text of the gold_tables from gold_dataset.jsonl.

RAGAS Dataset structure
-----------------------
  question       : NL question
  contexts       : list of retrieved YAML descriptions (one per retrieved table)
  reference      : concatenated YAML descriptions of gold tables

RAGAS metrics
-------------
  context_precision   How much of retrieved context is relevant? (LLM judge)
  context_recall      Are all gold context sentences present in retrieved? (LLM judge)

Note: RAGAS uses an LLM (via langchain) to judge relevance. We configure it
to use the local Ollama model so no external API keys are needed.

How to run
----------
  cd /path/to/citizen360
  python tests/eval_retrieval_l2_ragas.py

  # Subset for quick test (RAGAS is slow — each question needs 2 LLM calls):
  python tests/eval_retrieval_l2_ragas.py --n 10

  # Via pytest:
  pytest tests/eval_retrieval_l2_ragas.py -v -s
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path
from typing import Any

import pytest
import yaml as _yaml

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT.parent))
sys.path.insert(0, str(ROOT))

from citizen360.nodes.rag_retrieval import make_rag_retrieval_node
from citizen360.plugins.llm.ollama_provider import OllamaProvider
from citizen360.plugins.vector.milvus_lite import MilvusLiteStore
from citizen360.plugins.workspace.registry import WorkspaceRegistry
from citizen360.config import settings

GOLD_PATH  = ROOT / "data" / "gold_dataset.jsonl"
SCHEMA_DIR = ROOT / "schema"

# Map workspace_id → subfolder name
_WS_TO_FOLDER = {
    "school": "school",
    "canonical_model": "canonicalmodel",
    "misc": "misc",
}


# ── YAML text loader (cached) ──────────────────────────────────────────────────

_yaml_cache: dict[str, str] = {}


def _load_yaml_text(table_name: str, workspace_id: str) -> str:
    """
    Return the raw YAML text for a table, searched across all schema folders.
    Returns empty string if not found.
    """
    if table_name in _yaml_cache:
        return _yaml_cache[table_name]

    # Try workspace-specific folder first, then all others
    folders = [_WS_TO_FOLDER.get(workspace_id, workspace_id)] + list(_WS_TO_FOLDER.values())
    for folder_name in folders:
        path = SCHEMA_DIR / folder_name / f"{table_name}.yaml"
        if path.exists():
            with path.open(encoding="utf-8") as fh:
                data = _yaml.safe_load(fh) or {}
            # Build rich text
            parts = []
            desc = data.get("description", "")
            if desc:
                parts.append(f"Table {table_name}: {desc}")
            for col in data.get("columns", [])[:12]:
                parts.append(
                    f"Column {col.get('name', '')} ({col.get('type', '')}): "
                    f"{col.get('description', '')[:100]}"
                )
            text = "\n".join(parts) if parts else f"Table: {table_name}"
            _yaml_cache[table_name] = text
            return text

    # Table not in our schema (may be from canonicalmodel in school queries, etc.)
    fallback = f"Table: {table_name} (schema not found locally)"
    _yaml_cache[table_name] = fallback
    return fallback


# ── Build RAGAS dataset ────────────────────────────────────────────────────────

async def build_ragas_dataset(n: int | None = None) -> list[dict]:
    """
    Run retrieval on gold questions and build a RAGAS-compatible dataset.

    Each item:
      question   : str
      contexts   : list[str]  (retrieved YAML descriptions)
      reference  : str        (gold YAML descriptions concatenated)
    """
    llm = OllamaProvider(
        base_url=settings.OLLAMA_BASE_URL,
        embed_model=settings.EMBEDDING_MODEL,
    )
    registry = WorkspaceRegistry()
    store = MilvusLiteStore(
        db_path=settings.MILVUS_DB_PATH,
        sql_col=settings.MILVUS_COLLECTION_SQL_EXAMPLES,
        tables_col=settings.MILVUS_COLLECTION_TABLES,
    )
    await store.initialize()

    rag_node = make_rag_retrieval_node(
        llm=llm,
        vector_store=store,
        workspace_registry=registry,
        top_k_tables=settings.TOP_K_CANDIDATE_TABLES,
    )

    table_to_ws = {}
    for ws_id in registry.list_ids():
        for t in registry.get(ws_id).candidate_tables:
            table_to_ws[t] = ws_id

    gold_cases: list[dict] = []
    with GOLD_PATH.open() as f:
        for i, line in enumerate(f):
            if n and i >= n:
                break
            gold_cases.append(json.loads(line))

    print(f"\n[L2-RAGAS] Building dataset from {len(gold_cases)} questions …")
    dataset: list[dict] = []

    for i, case in enumerate(gold_cases, 1):
        q = case["question"]
        gold_tables: list[str] = case["gold_tables"]
        workspace_id: str = case["workspace_id"]

        gold_ws = sorted(list(set(table_to_ws.get(t) for t in gold_tables if table_to_ws.get(t))))
        if not gold_ws:
            gold_ws = [workspace_id]

        state: dict[str, Any] = {
            "raw_question": q,
            "workspace_ids": gold_ws,
            "is_multi_domain": len(gold_ws) > 1,
        }
        try:
            out = await rag_node(state)
            retrieved_tables: list[str] = out.get("candidate_tables", [])
        except Exception as exc:
            print(f"  [{i:03d}] RAG error: {exc}")
            retrieved_tables = []

        # Build context strings from YAML descriptions
        contexts = [_load_yaml_text(t, workspace_id) for t in retrieved_tables if t]

        # Build reference from gold YAML descriptions
        reference = "\n\n".join(
            _load_yaml_text(t, workspace_id) for t in gold_tables
        )

        dataset.append({
            "question": q,
            "contexts": contexts,
            "reference": reference,
            "gold_tables": gold_tables,
            "retrieved_tables": retrieved_tables,
            "workspace_id": workspace_id,
        })

        print(f"  [{i:03d}] retrieved={len(retrieved_tables)} tables | {q[:60]}")

    return dataset


# ── Custom precision / recall without LLM judge ───────────────────────────────
# These are fast proxies for RAGAS metrics, usable even without an LLM judge.

def _table_set_precision(retrieved: list[str], gold: list[str]) -> float:
    if not retrieved:
        return 0.0
    gold_set = set(gold)
    return sum(1 for t in retrieved if t in gold_set) / len(retrieved)


def _table_set_recall(retrieved: list[str], gold: list[str]) -> float:
    if not gold:
        return 1.0
    gold_set = set(gold)
    return sum(1 for t in gold_set if t in retrieved) / len(gold_set)


# ── RAGAS evaluation (with local Ollama LLM judge) ────────────────────────────

def _run_ragas_metrics(dataset: list[dict]) -> dict:
    """
    Run RAGAS ContextPrecision and ContextRecall using local Ollama.

    Falls back to custom set-overlap metrics if RAGAS/langchain fails.
    """
    try:
        from ragas import evaluate
        from ragas.metrics import context_precision, context_recall
        from ragas.llms import LangchainLLMWrapper
        from langchain_community.llms import Ollama as LangchainOllama
        from datasets import Dataset

        print("\n[L2-RAGAS] Running RAGAS evaluation with local Ollama judge …")

        # Configure RAGAS to use local Ollama
        local_llm = LangchainOllama(
            base_url=settings.OLLAMA_BASE_URL,
            model=settings.OLLAMA_MODEL,
        )
        ragas_llm = LangchainLLMWrapper(local_llm)

        # Build HuggingFace Dataset (RAGAS format)
        hf_data = {
            "question": [d["question"] for d in dataset],
            "contexts": [d["contexts"] for d in dataset],
            "reference": [d["reference"] for d in dataset],
        }
        hf_dataset = Dataset.from_dict(hf_data)

        result = evaluate(
            dataset=hf_dataset,
            metrics=[context_precision, context_recall],
            llm=ragas_llm,
            raise_exceptions=False,
        )

        scores = result.to_pandas()
        return {
            "method": "ragas",
            "context_precision": float(scores["context_precision"].mean()),
            "context_recall": float(scores["context_recall"].mean()),
            "n": len(dataset),
        }

    except ImportError as exc:
        print(f"  [RAGAS not installed or langchain missing] → Using custom set-overlap metrics. ({exc})")
    except Exception as exc:
        print(f"  [RAGAS evaluation failed: {exc}] → Falling back to custom metrics.")

    # ── Fallback: custom set-overlap (same concept, no LLM judge) ─────────────
    precisions = [_table_set_precision(d["retrieved_tables"], d["gold_tables"]) for d in dataset]
    recalls    = [_table_set_recall(d["retrieved_tables"],    d["gold_tables"]) for d in dataset]
    avg_prec = sum(precisions) / len(precisions) if precisions else 0.0
    avg_rec  = sum(recalls) / len(recalls) if recalls else 0.0
    return {
        "method": "custom_set_overlap",
        "context_precision": avg_prec,
        "context_recall": avg_rec,
        "n": len(dataset),
    }


# ── Full evaluation runner ─────────────────────────────────────────────────────

async def run_l2_eval(n: int | None = None) -> dict:
    dataset = await build_ragas_dataset(n=n)
    if not dataset:
        print("No data. Build gold dataset first: python scripts/build_gold_dataset.py")
        return {}

    scores = _run_ragas_metrics(dataset)

    print(f"\n{'═'*60}")
    print(f"  Level 2 — RAGAS Evaluation Results  (method={scores['method']})")
    print(f"{'─'*60}")
    print(f"  Questions evaluated  : {scores['n']}")
    print(f"  Context Precision    : {scores['context_precision']:.1%}")
    print(f"  Context Recall       : {scores['context_recall']:.1%}")
    print(f"{'─'*60}")
    print(f"  Context Precision: How much retrieved context is relevant?")
    print(f"  Context Recall:    Did we bring all required table context?")
    print(f"{'═'*60}\n")

    return scores


# ── Pytest tests ───────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_l2_context_recall():
    """
    RAGAS Context Recall must be ≥ 0.60 on 10 questions.
    """
    try:
        scores = await run_l2_eval(n=10)
    except FileNotFoundError as exc:
        pytest.skip(str(exc))
    except Exception as exc:
        pytest.skip(f"Retrieval unavailable: {exc}")

    if not scores:
        pytest.skip("No scores returned.")

    assert scores["context_recall"] >= 0.60, (
        f"Context Recall {scores['context_recall']:.1%} below 60%.\n"
        "Run 'python scripts/index_tables.py' to populate the vector index."
    )


@pytest.mark.asyncio
async def test_l2_context_precision():
    """RAGAS Context Precision must be ≥ 0.30 (retrieval shouldn't be too noisy)."""
    try:
        scores = await run_l2_eval(n=10)
    except Exception as exc:
        pytest.skip(f"Retrieval unavailable: {exc}")

    if not scores:
        pytest.skip("No scores returned.")

    assert scores["context_precision"] >= 0.30, (
        f"Context Precision {scores['context_precision']:.1%} below 30%.\n"
        "Too many irrelevant tables being retrieved."
    )


# ── Standalone ─────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--n", type=int, default=None)
    args = p.parse_args()
    asyncio.run(run_l2_eval(n=args.n))
