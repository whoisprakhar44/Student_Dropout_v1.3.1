"""
tests/eval_retrieval_l1.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~
Level 1 Retrieval Evaluation — Custom Table-Level Metrics

The most important evaluation for NL2SQL retrieval.
No LLM judge needed — pure set-matching against gold_dataset.jsonl.

Metrics computed
----------------
  Recall@K      fraction of gold tables found in top-K retrieved tables
  Precision@K   fraction of retrieved tables that are in the gold set
  Hit@K         1 if ALL gold tables are in top-K results, else 0
  MRR           Mean Reciprocal Rank of first gold table hit
  F1@K          harmonic mean of Precision@K and Recall@K

Reported at K = 5, 8, 10 (matching top_k_tables=10 default).

Primary KPI: **Recall@8** — target ≥ 95% before touching prompts.

How to run
----------
  # Requires Ollama running + tables indexed:
  #   python scripts/index_tables.py
  #   python scripts/index_examples.py

  # Run evaluation:
  cd /path/to/citizen360
  python tests/eval_retrieval_l1.py

  # Or via pytest (slower, runs all):
  pytest tests/eval_retrieval_l1.py -v -s

  # Subset for quick smoke-test:
  python tests/eval_retrieval_l1.py --n 20
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT.parent))
sys.path.insert(0, str(ROOT))

from citizen360.nodes.rag_retrieval import make_rag_retrieval_node
from citizen360.plugins.llm.ollama_provider import OllamaProvider
from citizen360.plugins.vector.milvus_lite import MilvusLiteStore
from citizen360.plugins.workspace.registry import WorkspaceRegistry
from citizen360.config import settings

GOLD_PATH = ROOT / "data" / "gold_dataset.jsonl"


# ── Data structures ────────────────────────────────────────────────────────────

@dataclass
class CaseResult:
    question: str
    gold_tables: list[str]
    retrieved_tables: list[str]
    workspace_id: str
    difficulty: str

    def recall_at_k(self, k: int) -> float:
        if not self.gold_tables:
            return 1.0
        top_k = self.retrieved_tables[:k]
        gold_set = set(self.gold_tables)
        return sum(1 for t in gold_set if t in top_k) / len(gold_set)

    def precision_at_k(self, k: int) -> float:
        top_k = self.retrieved_tables[:k]
        if not top_k:
            return 0.0
        gold_set = set(self.gold_tables)
        return sum(1 for t in top_k if t in gold_set) / len(top_k)

    def hit_at_k(self, k: int) -> int:
        """1 if ALL gold tables appear in top-K, else 0."""
        top_k_set = set(self.retrieved_tables[:k])
        return 1 if all(t in top_k_set for t in self.gold_tables) else 0

    def mrr(self) -> float:
        """Mean Reciprocal Rank — rank of first gold table hit."""
        gold_set = set(self.gold_tables)
        for rank, table in enumerate(self.retrieved_tables, start=1):
            if table in gold_set:
                return 1.0 / rank
        return 0.0

    def f1_at_k(self, k: int) -> float:
        p = self.precision_at_k(k)
        r = self.recall_at_k(k)
        if p + r == 0:
            return 0.0
        return 2 * p * r / (p + r)


@dataclass
class EvalSummary:
    k_values: list[int]
    total: int
    results: list[CaseResult] = field(default_factory=list)

    def avg_recall(self, k: int) -> float:
        return sum(r.recall_at_k(k) for r in self.results) / self.total

    def avg_precision(self, k: int) -> float:
        return sum(r.precision_at_k(k) for r in self.results) / self.total

    def avg_hit(self, k: int) -> float:
        return sum(r.hit_at_k(k) for r in self.results) / self.total

    def avg_mrr(self) -> float:
        return sum(r.mrr() for r in self.results) / self.total

    def avg_f1(self, k: int) -> float:
        return sum(r.f1_at_k(k) for r in self.results) / self.total

    def by_difficulty(self, k: int) -> dict[str, dict]:
        groups: dict[str, list[CaseResult]] = {}
        for r in self.results:
            groups.setdefault(r.difficulty, []).append(r)
        out = {}
        for diff, cases in groups.items():
            n = len(cases)
            out[diff] = {
                "n": n,
                f"recall@{k}": round(sum(c.recall_at_k(k) for c in cases) / n, 3),
                f"hit@{k}": round(sum(c.hit_at_k(k) for c in cases) / n, 3),
            }
        return out


# ── Load gold data ─────────────────────────────────────────────────────────────

def load_gold(n: int | None = None) -> list[dict]:
    if not GOLD_PATH.exists():
        raise FileNotFoundError(
            f"Gold dataset not found at {GOLD_PATH}\n"
            "Run: python scripts/build_gold_dataset.py"
        )
    records = []
    with GOLD_PATH.open() as f:
        for line in f:
            records.append(json.loads(line))
            if n and len(records) >= n:
                break
    return records


# ── Core eval loop ─────────────────────────────────────────────────────────────

async def run_l1_eval(
    n: int | None = None,
    k_values: list[int] | None = None,
    verbose: bool = True,
) -> EvalSummary:
    """
    Run the RAG retrieval node on every gold question and compute
    Recall@K, Precision@K, Hit@K, MRR, F1@K.
    """
    if k_values is None:
        k_values = [5, 8, 10]

    llm = OllamaProvider(
        base_url=settings.OLLAMA_BASE_URL,
        embed_model=settings.EMBEDDING_MODEL,
    )
    registry = WorkspaceRegistry()
    store = MilvusLiteStore(
        db_path=settings.MILVUS_DB_PATH,
        collection=settings.MILVUS_COLLECTION,
    )
    await store.initialize()

    rag_node = make_rag_retrieval_node(
        llm=llm,
        vector_store=store,
        workspace_registry=registry,
        top_k_sql=settings.TOP_K_SQL_EXAMPLES,
        top_k_tables=max(k_values),   # retrieve at max-K so all K values are covered
    )

    table_to_ws = {}
    for ws_id in registry.list_ids():
        for t in registry.get(ws_id).candidate_tables:
            table_to_ws[t] = ws_id

    gold_cases = load_gold(n)
    summary = EvalSummary(k_values=k_values, total=len(gold_cases))

    print(f"\n{'═'*70}")
    print(f"  Level 1 Retrieval Evaluation  |  {len(gold_cases)} questions  |  K={k_values}")
    print(f"{'═'*70}\n")

    for i, case in enumerate(gold_cases, 1):
        q = case["question"]
        gold_tables: list[str] = case["gold_tables"]
        workspace_id: str = case["workspace_id"]

        gold_ws = sorted(list(set(table_to_ws.get(t) for t in gold_tables if table_to_ws.get(t))))
        if not gold_ws:
            gold_ws = [workspace_id]

        state: dict[str, Any] = {
            "raw_question": q,
            "workspace_ids": gold_ws,
            "is_multi_domain": len(gold_ws) > 1,
        }
        try:
            out = await rag_node(state)
            retrieved = out.get("candidate_tables", [])
        except Exception as exc:
            print(f"  [{i:03d}] ERROR: {exc}")
            retrieved = []

        result = CaseResult(
            question=q,
            gold_tables=gold_tables,
            retrieved_tables=retrieved,
            workspace_id=workspace_id,
            difficulty=case.get("difficulty", "medium"),
        )
        summary.results.append(result)

        if verbose:
            k = 8
            r8 = result.recall_at_k(k)
            h8 = result.hit_at_k(k)
            status = "✓" if h8 else ("~" if r8 > 0 else "✗")
            print(
                f"  {status} [{i:03d}] recall@{k}={r8:.2f}  "
                f"gold={gold_tables}  "
                f"retrieved={retrieved[:5]}{'…' if len(retrieved) > 5 else ''}"
            )

    _print_summary(summary)
    return summary


def _print_summary(s: EvalSummary) -> None:
    print(f"\n{'═'*70}")
    print(f"  RETRIEVAL EVALUATION RESULTS  (N={s.total})")
    print(f"{'─'*70}")

    header = f"  {'Metric':<22}" + "".join(f"  K={k:<6}" for k in s.k_values)
    print(header)
    print(f"  {'─'*20}" + "─" * (9 * len(s.k_values)))

    for label, fn in [
        ("Recall@K",    s.avg_recall),
        ("Precision@K", s.avg_precision),
        ("Hit@K",       s.avg_hit),
        ("F1@K",        s.avg_f1),
    ]:
        row = f"  {label:<22}" + "".join(f"  {fn(k):.3f}   " for k in s.k_values)
        print(row)

    print(f"  {'MRR':<22}  {s.avg_mrr():.3f}")
    print(f"{'─'*70}")

    # Primary KPI callout
    k_primary = 8 if 8 in s.k_values else s.k_values[-1]
    recall_primary = s.avg_recall(k_primary)
    hit_primary = s.avg_hit(k_primary)
    bar = "█" * int(recall_primary * 40) + "░" * (40 - int(recall_primary * 40))
    print(f"\n  ⭐ PRIMARY KPI:  Recall@{k_primary} = {recall_primary:.1%}  {bar}")
    print(f"  ⭐ PRIMARY KPI:  Hit@{k_primary}    = {hit_primary:.1%}")

    target = recall_primary >= 0.95
    if target:
        print(f"\n  ✅ Recall@{k_primary} ≥ 95% — retrieval is good! Move on to SQL generation.")
    else:
        gap = 0.95 - recall_primary
        print(f"\n  ⚠️  Recall@{k_primary} = {recall_primary:.1%} — {gap:.1%} below 95% target.")
        print(f"     → Improve retrieval BEFORE tuning SQL prompts.")
        print(f"     → Try: richer YAML embeddings, larger top_k, reranking.")

    # By difficulty
    print(f"\n{'─'*70}")
    print(f"  By Difficulty (Recall@{k_primary} | Hit@{k_primary})")
    print(f"{'─'*70}")
    for diff, metrics in sorted(s.by_difficulty(k_primary).items()):
        n = metrics["n"]
        rec = metrics.get(f"recall@{k_primary}", 0)
        hit = metrics.get(f"hit@{k_primary}", 0)
        print(f"  {diff:<12}  n={n:<4}  recall={rec:.3f}  hit={hit:.3f}")

    print(f"{'═'*70}\n")


# ── Pytest integration ─────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_recall_at_8_above_threshold():
    """
    Primary KPI: Recall@8 must be ≥ 0.80 (on the first 30 questions).
    Target in production is ≥ 0.95 after full indexing.
    """
    try:
        summary = await run_l1_eval(n=30, k_values=[5, 8, 10], verbose=False)
    except FileNotFoundError as exc:
        pytest.skip(str(exc))
    except Exception as exc:
        pytest.skip(f"Ollama / Milvus unavailable: {exc}")

    r8 = summary.avg_recall(8)
    assert r8 >= 0.80, (
        f"Recall@8 = {r8:.1%} — below 80% minimum.\n"
        "Run 'python scripts/index_tables.py' then retry."
    )


@pytest.mark.asyncio
async def test_hit_at_8_smoke():
    """Hit@8 must be ≥ 0.50 on easy questions."""
    try:
        gold = load_gold()
        easy = [c for c in gold if c.get("difficulty") == "easy"][:10]
        if not easy:
            pytest.skip("No 'easy' questions in gold dataset.")

        llm = OllamaProvider(base_url=settings.OLLAMA_BASE_URL, embed_model=settings.EMBEDDING_MODEL)
        registry = WorkspaceRegistry()
        store = MilvusLiteStore(db_path=settings.MILVUS_DB_PATH, collection=settings.MILVUS_COLLECTION)
        await store.initialize()
        rag_node = make_rag_retrieval_node(llm=llm, vector_store=store, workspace_registry=registry)

        table_to_ws = {}
        for ws_id in registry.list_ids():
            for t in registry.get(ws_id).candidate_tables:
                table_to_ws[t] = ws_id

        hits = []
        for case in easy:
            gold_ws = sorted(list(set(table_to_ws.get(t) for t in case["gold_tables"] if table_to_ws.get(t))))
            if not gold_ws:
                gold_ws = [case["workspace_id"]]

            state = {
                "raw_question": case["question"],
                "workspace_ids": gold_ws,
                "is_multi_domain": len(gold_ws) > 1,
            }
            out = await rag_node(state)
            retrieved = out.get("candidate_tables", [])
            gold_set = set(case["gold_tables"])
            hits.append(1 if all(t in set(retrieved[:8]) for t in gold_set) else 0)

        hit8 = sum(hits) / len(hits)
        assert hit8 >= 0.50, f"Hit@8 on easy questions = {hit8:.1%} — below 50%"

    except FileNotFoundError as exc:
        pytest.skip(str(exc))
    except Exception as exc:
        pytest.skip(f"Ollama / Milvus unavailable: {exc}")


# ── Standalone runner ──────────────────────────────────────────────────────────

def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Level 1 retrieval evaluation.")
    p.add_argument("--n", type=int, default=None, help="Number of questions (default: all)")
    p.add_argument("--k", type=int, nargs="+", default=[5, 8, 10], help="K values for metrics")
    p.add_argument("--quiet", action="store_true", help="Suppress per-question output")
    return p.parse_args()


if __name__ == "__main__":
    args = _parse_args()
    asyncio.run(run_l1_eval(n=args.n, k_values=args.k, verbose=not args.quiet))
