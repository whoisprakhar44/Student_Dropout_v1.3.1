"""
scripts/index_tables.py
~~~~~~~~~~~~~~~~~~~~~~~~
Index YAML table descriptions into Milvus-Lite — schema_store partition.

Architecture mirrors Student Dropout v1.3.1 pipeline.py:
  • Reads every .yaml file under schema/<cluster>/
  • Builds rich embedding_text (same format as Student Dropout extract_embedding_text)
  • Embeds with Ollama nomic-embed-text
  • Upserts into the `schema_store` partition of the single collection
  • Also indexes join_relations.yaml as a special __join_relations__ chunk

Run (from citizen360 project root):
    python scripts/index_tables.py
    python scripts/index_tables.py --schema-dir schema --db ./milvus_lite.db
"""
from __future__ import annotations

import argparse
import asyncio
import logging
import sys
import uuid
from pathlib import Path

import yaml

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
logger = logging.getLogger(__name__)

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT.parent))
sys.path.insert(0, str(ROOT))

# Folder name → canonical workspace_id
_FOLDER_TO_WORKSPACE = {
    "school":         "school",
    "canonicalmodel": "canonical_model",
    "misc":           "misc",
}

# Max chars to pass to Ollama embed — keeps context safe (~1024 tokens)
_MAX_EMBED_CHARS = 4096


def _load_yaml(path: Path) -> dict:
    with path.open(encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def extract_embedding_text(schema: dict) -> str:
    """
    Build rich embedding text from a parsed YAML schema dict.

    Matches Student Dropout pipeline.py extract_embedding_text() exactly:
        Table {name} in database {db}. {description}
        Columns: col1 (type, key key: desc, e.g. val1, val2); ...
        Business concepts: term1, term2.
        Common operations: op1, op2.
        Sample values — col: v1, v2; col2: v3.
        Relationships: rel1, rel2.
    """
    parts: list[str] = []

    table    = schema.get("table", "")
    database = schema.get("database", "curated_datamodels")
    desc     = schema.get("description", "")

    parts.append(f"Table {table} in database {database}.")
    if desc:
        parts.append(desc)

    # Columns — full detail including key, description, sample_values
    columns = schema.get("columns", [])
    if columns:
        col_parts = []
        for col in columns:
            name     = col.get("name", "")
            dtype    = col.get("type", "")
            col_desc = col.get("description", "")
            key      = col.get("key", "")
            sample   = col.get("sample_values", [])

            col_str = f"{name} ({dtype}"
            if key:
                col_str += f", {key} key"
            col_str += ")"
            if col_desc:
                col_str += f": {col_desc[:200]}"
            if sample:
                col_str += f", e.g. {', '.join(str(s) for s in sample[:5])}"
            col_parts.append(col_str)
        parts.append("Columns: " + "; ".join(col_parts) + ".")

    # Business terms
    biz_terms = schema.get("business_terms", [])
    if biz_terms:
        parts.append("Business concepts: " + ", ".join(biz_terms) + ".")

    # Common operations
    ops = schema.get("common_operations", [])
    if ops:
        parts.append("Common operations: " + ", ".join(ops) + ".")

    # Sample values (top-level dict)
    sample_values = schema.get("sample_values", {})
    if isinstance(sample_values, dict) and sample_values:
        sv_parts = [
            f"{col}: {', '.join(str(v) for v in vals)}"
            for col, vals in sample_values.items()
        ]
        parts.append("Sample values — " + "; ".join(sv_parts) + ".")

    # Relationships
    relationships = schema.get("relationships", [])
    if relationships:
        parts.append("Relationships: " + ", ".join(str(r) for r in relationships) + ".")

    return " ".join(parts)


def _load_join_relations(path: Path) -> str:
    """
    Build embedding text for join_relations.yaml.
    Mirrors Student Dropout build_milvus_index.py load_join_chunks().
    """
    if not path.is_file():
        return ""

    with open(path, "r", encoding="utf-8") as f:
        doc = yaml.safe_load(f) or {}

    database_name = doc.get("database", "curated_datamodels")
    joins         = doc.get("joins") or []
    key_columns   = doc.get("key_columns") or []
    strict_rules  = doc.get("strict_rules") or []

    lines = [doc.get("description", "Join relations for curated school data model.")]

    lines.append("\nKEY JOIN RELATIONSHIPS:")
    for join in joins:
        lines.append(
            "{name}: {from_table}.{from_column} -> {to_table}.{to_column} "
            "({cardinality}). Usage: {usage}".format(
                name=join.get("name", "join"),
                from_table=join.get("from_table", ""),
                from_column=join.get("from_column", ""),
                to_table=join.get("to_table", ""),
                to_column=join.get("to_column", ""),
                cardinality=join.get("cardinality", "unknown"),
                usage=join.get("usage", ""),
            )
        )

    if key_columns:
        lines.append(
            "\nKEY COLUMNS (use these exact names — do NOT guess or invent column names):"
        )
        for kc in key_columns:
            lines.append(f"- {kc.get('table', '')}: {kc.get('columns', '')}")

    if strict_rules:
        lines.append("\nSTRICT RULES — follow every rule without exception:")
        for i, rule in enumerate(strict_rules, 1):
            lines.append(f"{i}. {rule}")

    embedding_text = "Database: {db}\nChunk: join_relations\n{body}".format(
        db=database_name,
        body="\n".join(lines),
    )
    return embedding_text


async def _run(schema_dir: Path, db_path: str, collection: str) -> None:
    from citizen360.plugins.llm.ollama_provider import OllamaProvider
    from citizen360.plugins.vector.milvus_lite import MilvusLiteStore, PARTITION_SCHEMA
    from citizen360.config import settings

    llm = OllamaProvider(
        base_url=settings.OLLAMA_BASE_URL,
        embed_model=settings.EMBEDDING_MODEL,
    )
    store = MilvusLiteStore(db_path=db_path, collection=collection)

    # Drop and recreate so schema/embedding changes are applied cleanly
    store.drop_collection()
    await store.initialize()

    records: list[dict] = []

    # ── Schema YAML files ─────────────────────────────────────────────────────
    for cluster_folder in sorted(schema_dir.iterdir()):
        if not cluster_folder.is_dir():
            continue
        workspace_id = _FOLDER_TO_WORKSPACE.get(cluster_folder.name, cluster_folder.name)

        yaml_files = sorted(cluster_folder.glob("*.yaml"))
        logger.info(
            "Cluster '%s' (%s): %d YAML files",
            workspace_id, cluster_folder.name, len(yaml_files),
        )

        for yaml_path in yaml_files:
            schema = _load_yaml(yaml_path)
            if not schema:
                continue
            table_name     = schema.get("table") or yaml_path.stem
            database_name  = schema.get("database", "curated_datamodels")
            raw_ddl        = schema.get("raw_ddl", "")
            embedding_text = extract_embedding_text(schema)

            # Truncate embedding text before sending to Ollama
            embedding = await llm.embed(embedding_text[:_MAX_EMBED_CHARS])

            records.append({
                "id":             str(uuid.uuid4()),
                "database_name":  database_name,
                "table_name":     table_name,
                "embedding_text": embedding_text[:10000],
                "raw_ddl":        raw_ddl[:65535],
                "source_file":    str(yaml_path),
                "workspace_id":   workspace_id,
                "embedding":      embedding,
            })
            logger.debug("  Embedded: %s (%d chars)", table_name, len(embedding_text))

    # ── Join relations ────────────────────────────────────────────────────────
    join_path = schema_dir / "join_relations.yaml"
    if join_path.is_file():
        logger.info("Indexing join relations from %s", join_path)
        join_text = _load_join_relations(join_path)
        if join_text:
            join_embedding = await llm.embed(join_text[:_MAX_EMBED_CHARS])
            for ws_id in list(_FOLDER_TO_WORKSPACE.values()):
                records.append({
                    "id":             str(uuid.uuid4()),
                    "database_name":  "curated_datamodels",
                    "table_name":     "__join_relations__",
                    "embedding_text": join_text[:10000],
                    "raw_ddl":        "",
                    "source_file":    str(join_path),
                    "workspace_id":   ws_id,
                    "embedding":      join_embedding,
                })
            logger.info("  Indexed join relations for %d workspaces.", len(_FOLDER_TO_WORKSPACE))

    # ── Insert into schema_store partition ────────────────────────────────────
    logger.info("Inserting %d records into schema_store partition …", len(records))
    store.insert(records, partition=PARTITION_SCHEMA)
    logger.info("Done ✓ — %d schema records indexed.", len(records))


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Index YAML table descriptions into Milvus-Lite (schema_store partition)."
    )
    parser.add_argument(
        "--schema-dir", type=Path, default=ROOT / "schema",
        help="Root schema directory with cluster subfolders (default: ./schema).",
    )
    parser.add_argument(
        "--db", default="./milvus_lite.db",
        help="Milvus-Lite .db file path (default: ./milvus_lite.db).",
    )
    parser.add_argument(
        "--collection", default="schema_index",
        help="Collection name (default: schema_index).",
    )
    args = parser.parse_args()
    asyncio.run(_run(args.schema_dir, args.db, args.collection))


if __name__ == "__main__":
    main()
