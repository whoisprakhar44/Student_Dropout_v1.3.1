"""
scripts/build_gold_dataset.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Convert fewshot JSONL files into a retrieval benchmark gold dataset.

Output format (data/gold_dataset.jsonl):
-----------------------------------------
{
  "id":           "school_dropout_011",
  "question":     "Which schools in Anantapur have attendance below 55%?",
  "gold_tables":  ["school_student_attendance_fact", "citizen_school"],
  "workspace_id": "school",
  "difficulty":   "medium",
  "n_tables":     2
}

Usage:
  python scripts/build_gold_dataset.py
  python scripts/build_gold_dataset.py --out data/gold_dataset.jsonl
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT.parent))
sys.path.insert(0, str(ROOT))

# ── Workspace table → cluster mapping ─────────────────────────────────────────
# Derived from our schema/ folder contents
_SCHOOL_TABLES = {
    "absent_reason_dim", "assessment_dim", "beneficiary_type_dim", "benefit_type_dim",
    "infrastructure_category_dim", "infrastructure_component_dim", "meal_type_dim",
    "mid_day_meal_serving_fact", "nutrition_item_dim", "scheme_benefits_fact",
    "school_academic_performance_fact", "school_infra_category_dim",
    "school_infra_component_dim", "school_infrastructure_progress_fact",
    "school_meal_menu_dim", "school_student_attendance_fact",
    "school_teacher_attendance_fact", "student_class_dim",
}
_CANONICAL_TABLES = {
    "citizen_address_master", "citizen_agriculture_land", "citizen_asset_electricity",
    "citizen_asset_vaahan", "citizen_asset_vaahan_type", "citizen_bank_accounts",
    "citizen_consent", "citizen_document", "citizen_education", "citizen_family_master",
    "citizen_health_schemes", "citizen_health_schemes_master", "citizen_idty",
    "citizen_idty_type", "citizen_land", "citizen_master", "citizen_property",
    "citizen_school", "citizen_school_teacher", "citizen_student",
    "citizen_utility_connection", "citizen_welfare_schemes", "citizen_welfare_schemes_master",
    "gsws_sec_secretariat_master", "health_scheme_code", "ration_card_citizen",
    "ration_card_citizen_reason", "ration_card_family", "ration_card_type",
    "school_category", "school_medium", "school_scheme_master", "school_subject_master",
    "source_department_code", "welfare_schemes_life_cycle",
}


def _strip_prefix(table: str) -> str:
    """curated_datamodels.school_student_attendance_fact → school_student_attendance_fact"""
    return table.split(".")[-1].strip()


def _infer_workspace(tables: list[str]) -> str:
    """Infer primary workspace from gold table set."""
    school_hits = sum(1 for t in tables if t in _SCHOOL_TABLES)
    canonical_hits = sum(1 for t in tables if t in _CANONICAL_TABLES)
    if school_hits >= canonical_hits:
        return "school"
    return "canonical_model"


def build_gold_dataset(
    input_files: list[Path],
    output_path: Path,
    deduplicate: bool = True,
) -> int:
    """
    Read fewshot JSONL files and write a gold retrieval benchmark.

    Returns the number of records written.
    """
    seen_ids: set[str] = set()
    records: list[dict] = []

    for src in input_files:
        if not src.exists():
            print(f"  SKIP (not found): {src}")
            continue
        print(f"  Reading {src} …")
        with src.open() as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                rec = json.loads(line)
                rec_id = rec.get("id", "")
                if deduplicate and rec_id in seen_ids:
                    continue
                seen_ids.add(rec_id)

                raw_tables = rec.get("tables", [])
                gold_tables = [_strip_prefix(t) for t in raw_tables]
                workspace_id = _infer_workspace(gold_tables)

                records.append({
                    "id": rec_id,
                    "question": rec["question"],
                    "gold_tables": gold_tables,
                    "workspace_id": workspace_id,
                    "difficulty": rec.get("difficulty", "medium"),
                    "intent": rec.get("intent", ""),
                    "topic": rec.get("topic", ""),
                    "n_tables": len(gold_tables),
                })

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w") as f:
        for rec in records:
            f.write(json.dumps(rec) + "\n")

    print(f"\n  ✓ Wrote {len(records)} gold records → {output_path}")
    return len(records)


def main() -> None:
    parser = argparse.ArgumentParser(description="Build retrieval gold dataset from fewshots.")
    parser.add_argument(
        "--out", type=Path, default=ROOT / "data" / "gold_dataset.jsonl",
        help="Output path for gold dataset JSONL.",
    )
    args = parser.parse_args()

    input_files = [
        ROOT / "data" / "fewshots.jsonl",         # 50 records (combined)
    ]
    print("Building gold dataset …")
    n = build_gold_dataset(input_files, args.out)
    print(f"Done — {n} unique benchmark questions.")


if __name__ == "__main__":
    main()
