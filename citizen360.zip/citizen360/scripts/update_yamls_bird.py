"""
scripts/update_yamls_bird.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Parses sample values from impala_tables_sample.txt and appends
BIRD-style '[Value Examples: ...]' annotation to matching column descriptions
in all schema YAML files across both citizen360 and student_dropout.
"""
import re
import yaml
from pathlib import Path

import os

CITIZEN360_ROOT = Path(os.environ.get("CITIZEN360_ROOT", Path(__file__).resolve().parent.parent))
STUDENT_DROPOUT_ROOT = Path(os.environ.get("STUDENT_DROPOUT_ROOT", CITIZEN360_ROOT.parent / "Student_Dropout_v1.3.1"))
IMPALA_TXT = STUDENT_DROPOUT_ROOT / "impala_tables_sample.txt"


def parse_impala_sample(txt_path: Path) -> dict[str, dict[str, list[str]]]:
    """
    Parse impala_tables_sample.txt and extract distinct values for each column.
    Returns: { table_name: { column_name: [val1, val2, ...] } }
    """
    if not txt_path.exists():
        raise FileNotFoundError(f"Sample file not found at {txt_path}")

    with open(txt_path, "r", encoding="utf-8") as f:
        content = f.read()

    # Split by Table header
    sections = re.split(r'-{40,}\nTable: curated_datamodels\.', content)
    
    results = {}

    for sec in sections[1:]:
        lines = sec.strip().split("\n")
        if not lines:
            continue
        
        table_name = lines[0].strip()
        # Clean any trailing info in the name line
        table_name = table_name.split()[0]
        
        # Check if table has rows
        if "(No rows found in this table.)" in sec or "Error querying table:" in sec:
            continue
            
        # Find the header line and separator line
        header_idx = -1
        sep_idx = -1
        for idx, line in enumerate(lines):
            if "|" in line and "---" in lines[idx+1] if idx+1 < len(lines) else False:
                header_idx = idx
                sep_idx = idx + 1
                break
                
        if header_idx == -1 or sep_idx == -1:
            continue
            
        headers = [h.strip().lower() for h in lines[header_idx].split("|")]
        
        # Collect rows
        col_vals = {h: [] for h in headers}
        for line in lines[sep_idx+1:]:
            line = line.strip()
            if not line or "Successfully fetched" in line:
                break
            if "|" not in line:
                continue
            parts = [p.strip() for p in line.split("|")]
            # Match columns to header length
            for h_idx, val in enumerate(parts[:len(headers)]):
                h_name = headers[h_idx]
                if val and val.lower() != "null" and val not in col_vals[h_name]:
                    col_vals[h_name].append(val)
                    
        results[table_name] = col_vals
        
    return results


def update_yaml_descriptions(yaml_path: Path, table_data: dict[str, list[str]]):
    """
    Load yaml_path, append BIRD-style value examples to column descriptions, and save.
    """
    with open(yaml_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    if not data or "columns" not in data:
        return False

    updated = False
    for col in data["columns"]:
        col_name = col.get("name", "").lower()
        if col_name in table_data:
            vals = table_data[col_name]
            if not vals:
                continue
            # Keep top 12 distinct values
            top_vals = vals[:12]
            # Format BIRD annotation
            annot = " [Value Examples: " + ", ".join(f"'{v}'" for v in top_vals) + "]"
            
            curr_desc = col.get("description", "") or ""
            # Prevent duplicate annotation
            if "[Value Examples:" not in curr_desc:
                col["description"] = (curr_desc.strip() + annot).strip()
                updated = True
                
    if updated:
        with open(yaml_path, "w", encoding="utf-8") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False, allow_unicode=True)
            
    return updated


def main():
    print("Parsing Impala table samples ...")
    db_samples = parse_impala_sample(IMPALA_TXT)
    print(f"Loaded samples for {len(db_samples)} tables.")

    # Find all yamls in both directories
    citizen360_yamls = list((CITIZEN360_ROOT / "schema").glob("**/*.yaml"))
    student_dropout_yamls = list((STUDENT_DROPOUT_ROOT / "schema/curated_datamodels/tables").glob("**/*.yaml"))

    print(f"Found {len(citizen360_yamls)} YAMLs in citizen360.")
    print(f"Found {len(student_dropout_yamls)} YAMLs in Student_Dropout.")

    # Update citizen360
    c_updated = 0
    for y_path in citizen360_yamls:
        t_name = y_path.stem
        if t_name in db_samples:
            if update_yaml_descriptions(y_path, db_samples[t_name]):
                c_updated += 1

    # Update student_dropout
    s_updated = 0
    for y_path in student_dropout_yamls:
        t_name = y_path.stem
        if t_name in db_samples:
            if update_yaml_descriptions(y_path, db_samples[t_name]):
                s_updated += 1

    print(f"Updated {c_updated} YAML descriptions in citizen360.")
    print(f"Updated {s_updated} YAML descriptions in Student_Dropout.")


if __name__ == "__main__":
    main()
