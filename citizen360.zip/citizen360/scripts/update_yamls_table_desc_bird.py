"""
scripts/update_yamls_table_desc_bird.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Parses sample rows from impala_tables_sample.txt, extracts representative
fields for the first 3 rows of each table, and appends a BIRD-style
'[Sample records: ...]' annotation to the table-level descriptions.
"""
import re
import yaml
from pathlib import Path

import os

CITIZEN360_ROOT = Path(os.environ.get("CITIZEN360_ROOT", Path(__file__).resolve().parent.parent))
STUDENT_DROPOUT_ROOT = Path(os.environ.get("STUDENT_DROPOUT_ROOT", CITIZEN360_ROOT.parent / "Student_Dropout_v1.3.1"))
IMPALA_TXT = STUDENT_DROPOUT_ROOT / "impala_tables_sample.txt"


def parse_impala_records(txt_path: Path) -> dict[str, list[dict[str, str]]]:
    """
    Parse impala_tables_sample.txt and return the first 3 rows of each table.
    Returns: { table_name: [ {col1: val1, col2: val2}, ... ] }
    """
    if not txt_path.exists():
        raise FileNotFoundError(f"Sample file not found at {txt_path}")

    with open(txt_path, "r", encoding="utf-8") as f:
        content = f.read()

    # Split by Table header
    sections = re.split(r'-{40,}\nTable: curated_datamodels\.', content)
    
    results = {}

    # Fields to ignore in table-level sample records (keeps the description concise)
    ignored_patterns = [
        r"_pk$", r"_fk$", r"created_date", r"updated_date",
        r"created_by", r"updated_by", r"effective_start_date", r"effective_end_date"
    ]

    for sec in sections[1:]:
        lines = sec.strip().split("\n")
        if not lines:
            continue
        
        table_name = lines[0].strip()
        table_name = table_name.split()[0]
        
        if "(No rows found in this table.)" in sec or "Error querying table:" in sec:
            continue
            
        header_idx = -1
        sep_idx = -1
        for idx, line in enumerate(lines):
            if "|" in line and "---" in lines[idx+1] if idx+1 < len(lines) else False:
                header_idx = idx
                sep_idx = idx + 1
                break
                
        if header_idx == -1 or sep_idx == -1:
            continue
            
        headers = [h.strip().lower() for h in lines[header_idx].split("|")]
        
        # Collect rows
        rows = []
        for line in lines[sep_idx+1:]:
            line = line.strip()
            if not line or "Successfully fetched" in line:
                break
            if "|" not in line:
                continue
            parts = [p.strip() for p in line.split("|")]
            
            # Build dict for this row
            row_dict = {}
            for h_idx, val in enumerate(parts[:len(headers)]):
                h_name = headers[h_idx]
                # Filter out NULL, empty, and system/audit/ID columns
                if val and val.lower() != "null":
                    is_ignored = any(re.search(pat, h_name) for pat in ignored_patterns)
                    if not is_ignored:
                        row_dict[h_name] = val
            if row_dict:
                rows.append(row_dict)
                if len(rows) >= 3: # limit to top 3 sample records
                    break
                    
        results[table_name] = rows
        
    return results


def update_table_description(yaml_path: Path, rows: list[dict[str, str]]):
    """
    Append BIRD-style sample records to the top-level table description.
    """
    with open(yaml_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    if not data:
        return False

    # Keep only descriptive columns up to 6 fields per record to prevent excessively long descriptions
    simplified_rows = []
    for r in rows:
        simple_r = {}
        count = 0
        for k, v in r.items():
            simple_r[k] = v
            count += 1
            if count >= 6:
                break
        if simple_r:
            simplified_rows.append(simple_r)

    if not simplified_rows:
        return False

    # Format the annotation
    annot = " [Sample records: " + ", ".join(str(r) for r in simplified_rows) + "]"
    curr_desc = data.get("description", "") or ""
    
    if "[Sample records:" not in curr_desc:
        data["description"] = (curr_desc.strip() + annot).strip()
        with open(yaml_path, "w", encoding="utf-8") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False, allow_unicode=True)
        return True

    return False


def main():
    print("Parsing table record samples ...")
    db_records = parse_impala_records(IMPALA_TXT)
    print(f"Loaded samples for {len(db_records)} tables.")

    citizen360_yamls = list((CITIZEN360_ROOT / "schema").glob("**/*.yaml"))
    student_dropout_yamls = list((STUDENT_DROPOUT_ROOT / "schema/curated_datamodels/tables").glob("**/*.yaml"))

    # Update citizen360
    c_updated = 0
    for y_path in citizen360_yamls:
        t_name = y_path.stem
        if t_name in db_records:
            if update_table_description(y_path, db_records[t_name]):
                c_updated += 1

    # Update student_dropout
    s_updated = 0
    for y_path in student_dropout_yamls:
        t_name = y_path.stem
        if t_name in db_records:
            if update_table_description(y_path, db_records[t_name]):
                s_updated += 1

    print(f"Updated {c_updated} table-level descriptions in citizen360.")
    print(f"Updated {s_updated} table-level descriptions in Student_Dropout.")


if __name__ == "__main__":
    main()
