"""
scripts/index_examples.py
~~~~~~~~~~~~~~~~~~~~~~~~~~
Index SQL few-shot examples into Milvus-Lite — few_shot_store partition.

Architecture mirrors Student Dropout v1.3.1 pipeline.py run_fewshot_pipeline():
  • Reads fewshots.jsonl (one JSON object per line)
  • NL question  → embedding_text (what gets embedded)
  • gold SQL     → raw_ddl        (stored alongside, used for table extraction)
  • use_case     → database_name
  • intent       → table_name
  • tables list  → stored as pipe-separated string in source_file field

After indexing, the rag_retrieval node searches few_shot_store and extracts
table names from the matched fewshots to boost candidate_tables — identical
to how Student Dropout's mcp_rag.py merges fewshot + schema hits.

Run (from citizen360 project root):
    python scripts/index_examples.py
    python scripts/index_examples.py --file data/fewshots.jsonl
"""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import sys
import uuid
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
logger = logging.getLogger(__name__)

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT.parent))
sys.path.insert(0, str(ROOT))

DEFAULT_FEWSHOTS = ROOT / "data" / "fewshots.jsonl"

# Minimum cosine similarity to accept a fewshot hit at retrieval time
# (same threshold as Student Dropout mcp_rag.py)
FEWSHOT_MIN_SCORE = 0.35


def load_fewshot_records(jsonl_path: Path) -> list[dict]:
    """
    Read the JSONL few-shot file and normalise to the internal dict format.

    Each fewshot is indexed under EVERY workspace whose tables it references.
    This is critical for citizen360 which is multi-workspace: a fewshot that
    touches both school tables (school_student_attendance_fact) AND canonical_model
    tables (citizen_student, citizen_school) must be discoverable from either
    workspace search.

    Field mapping → Milvus field  (mirrors Student Dropout pipeline.py):
    ─────────────────────────────────────────────────────────────────────
    question   → embedding_text   (what gets embedded)
    sql        → raw_ddl          (gold SQL stored as-is)
    use_case   → database_name    (domain tag)
    intent     → table_name       (intent tag)
    tables     → source_file      (pipe-separated bare table names for retrieval)
    workspace_id→ workspace_id    (derived from actual tables, not use_case)
    """
    # Build table → workspace_id map from registry
    import sys
    sys.path.insert(0, str(ROOT.parent))
    sys.path.insert(0, str(ROOT))
    from citizen360.plugins.workspace.registry import WorkspaceRegistry
    registry    = WorkspaceRegistry()
    table_to_ws: dict[str, str] = {}
    all_ws_ids: set[str]        = set()
    for ws_id in registry.list_ids():
        all_ws_ids.add(ws_id)
        for t in registry.get(ws_id).candidate_tables:
            table_to_ws[t] = ws_id

    records = []
    with open(jsonl_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            row = json.loads(line)

            # Extract bare table names (strip curated_datamodels. prefix)
            raw_tables  = row.get("tables", [])
            bare_tables = [t.split(".")[-1] for t in raw_tables if t]
            tables_str  = "|".join(bare_tables)

            # Derive the set of workspaces this fewshot touches
            touched_ws = set()
            for t in bare_tables:
                ws = table_to_ws.get(t)
                if ws:
                    touched_ws.add(ws)

            # Fallback: if no table mapped, guess from use_case
            if not touched_ws:
                use_case = row.get("use_case", "")
                ws_id    = row.get("workspace_id", "")
                if not ws_id:
                    ws_id = "school" if "school" in use_case else "canonical_model"
                touched_ws = {ws_id}

            # Emit one record per workspace (so fewshot is searchable from each)
            for ws_id in touched_ws:
                records.append({
                    "embedding_text": row["question"],
                    "raw_ddl":        row["sql"],
                    "database_name":  row.get("use_case", ""),
                    "table_name":     row.get("intent", ""),
                    "source_file":    tables_str,
                    "workspace_id":   ws_id,
                })

    logger.info(
        "Loaded %d fewshot JSONL rows → %d records (cross-workspace expansion).",
        sum(1 for _ in open(jsonl_path) if _.strip()),
        len(records),
    )
    return records


async def _run(file_path: Path, db_path: str, collection: str) -> None:
    from citizen360.plugins.llm.ollama_provider import OllamaProvider
    from citizen360.plugins.vector.milvus_lite import MilvusLiteStore, PARTITION_FEW_SHOT
    from citizen360.config import settings

    llm = OllamaProvider(
        base_url=settings.OLLAMA_BASE_URL,
        embed_model=settings.EMBEDDING_MODEL,
    )
    store = MilvusLiteStore(db_path=db_path, collection=collection)

    # Ensure collection + partitions exist (index_tables.py may have created them)
    await store.initialize()

    if not file_path.exists():
        raise FileNotFoundError(
            f"Few-shot file not found: {file_path}\n"
            "Generate it with: python scripts/build_gold_dataset.py"
        )

    logger.info("Loading few-shots from %s …", file_path)
    raw_records = load_fewshot_records(file_path)
    logger.info("Loaded %d few-shot record(s).", len(raw_records))

    logger.info("Embedding NL questions …")
    to_insert: list[dict] = []
    for i, rec in enumerate(raw_records, 1):
        embedding = await llm.embed(rec["embedding_text"])
        to_insert.append({
            "id":             str(uuid.uuid4()),
            "database_name":  rec["database_name"],
            "table_name":     rec["table_name"],
            "embedding_text": rec["embedding_text"][:10000],
            "raw_ddl":        rec["raw_ddl"][:65535],
            "source_file":    rec["source_file"][:512],   # pipe-sep table names
            "workspace_id":   rec["workspace_id"],
            "embedding":      embedding,
        })
        if i % 10 == 0:
            logger.info("  %d / %d embedded …", i, len(raw_records))

    # Insert into few_shot_store partition
    store.insert(to_insert, partition=PARTITION_FEW_SHOT)
    logger.info(
        "Done ✓ — %d few-shot records inserted into few_shot_store partition.",
        len(to_insert),
    )


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Index few-shot SQL examples into Milvus-Lite (few_shot_store partition)."
    )
    parser.add_argument(
        "--file", type=Path, default=DEFAULT_FEWSHOTS,
        help=f"Path to JSONL few-shot file (default: {DEFAULT_FEWSHOTS}).",
    )
    parser.add_argument(
        "--db", default="./milvus_lite.db",
        help="Milvus-Lite .db file path (default: ./milvus_lite.db).",
    )
    parser.add_argument(
        "--collection", default="schema_index",
        help="Collection name (default: schema_index — must match index_tables.py).",
    )
    args = parser.parse_args()
    asyncio.run(_run(args.file, args.db, args.collection))


if __name__ == "__main__":
    main()
