"""
citizen360.nodes.intent_agent
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
LangGraph node: Intent classification + entity resolution.

In a single LLM call this node:
  - Classifies the raw question into one or more workspace IDs
  - Resolves relative date/entity references to concrete values
  - Flags ambiguities without guessing

State keys written
------------------
  workspace_ids         list[str]
  is_multi_domain       bool
  resolved_entities     dict[str, str]
  ambiguities_flagged   list[str]
  error                 str | None   (only on failure)
"""
from __future__ import annotations

import json
import logging
from datetime import date
from functools import partial
from typing import Any

from pydantic import BaseModel, field_validator

# PipelineState is a plain dict at runtime — TypedDict only for IDE hints
PipelineState = dict[str, Any]

from citizen360.plugins.llm.base import LLMProvider
from citizen360.plugins.workspace.registry import WorkspaceRegistry

logger = logging.getLogger(__name__)

# ── Prompt constants ───────────────────────────────────────────────────────────

INTENT_SYSTEM_PROMPT = """\
You are an intent classification agent for a government analytics platform.
Classify the user's question into one or more of the following workspaces:
{workspace_list}

Also resolve any implicit entities in the question:
- Relative dates ("last week", "this year") to ISO date ranges using today's date {today}
- Ambiguous references — flag them, do not guess silently

Respond ONLY with valid JSON matching this exact schema:
{{
  "workspaces": [
    {{"id": "<workspace_id>", "confidence": <0.0-1.0>}}
  ],
  "is_multi_domain": <true|false>,
  "resolved_entities": {{
    "<entity_key>": "<resolved_value>"
  }},
  "ambiguities_flagged": ["<description of ambiguity>"]
}}

Rules:
- workspace id must be one of the provided list exactly — no invented IDs
- if confidence < 0.5 for all workspaces, return the single best guess with a low
  confidence score and flag the ambiguity
- is_multi_domain is true only if the question genuinely spans two workspaces
- resolved_entities is an empty object if nothing needs resolving
- ambiguities_flagged is an empty list if nothing is ambiguous\
"""

INTENT_USER_PROMPT = "Question: {question}"


# ── Output schema ──────────────────────────────────────────────────────────────

class WorkspaceConfidence(BaseModel):
    id: str
    confidence: float

    @field_validator("confidence")
    @classmethod
    def clamp(cls, v: float) -> float:
        return max(0.0, min(1.0, v))


class IntentAgentOutput(BaseModel):
    workspaces: list[WorkspaceConfidence]
    is_multi_domain: bool
    resolved_entities: dict[str, str]
    ambiguities_flagged: list[str]


# ── Node implementation ────────────────────────────────────────────────────────

async def intent_agent_node(
    state: PipelineState,
    *,
    llm: LLMProvider,
    workspace_registry: WorkspaceRegistry,
) -> dict:
    """
    Classify *state["raw_question"]* and resolve implicit entities.

    Returns a partial state dict with keys:
      workspace_ids, is_multi_domain, resolved_entities, ambiguities_flagged
    On error also sets: error
    """
    question: str = state.get("raw_question", "").strip()
    if not question:
        logger.error("intent_agent_node: raw_question is empty.")
        return {"error": "raw_question is empty", "workspace_ids": [], "is_multi_domain": False,
                "resolved_entities": {}, "ambiguities_flagged": []}

    today = date.today().isoformat()
    workspace_list = workspace_registry.format_for_prompt()

    system_prompt = INTENT_SYSTEM_PROMPT.format(
        workspace_list=workspace_list,
        today=today,
    )
    user_prompt = INTENT_USER_PROMPT.format(question=question)

    logger.info("IntentAgent: classifying question=%r workspaces=%s", question, workspace_registry.list_ids())

    # ── LLM call ──────────────────────────────────────────────────────────────
    raw: str = await llm.chat(system=system_prompt, user=user_prompt, json_mode=True)
    logger.debug("IntentAgent raw LLM response: %s", raw)

    # ── Parse ─────────────────────────────────────────────────────────────────
    try:
        data: dict[str, Any] = json.loads(raw)
        output = IntentAgentOutput.model_validate(data)
    except Exception as exc:
        logger.error("IntentAgent: failed to parse LLM response: %s — raw=%s", exc, raw)
        return {
            "error": f"IntentAgent parse error: {exc}",
            "workspace_ids": [],
            "is_multi_domain": False,
            "resolved_entities": {},
            "ambiguities_flagged": [],
        }

    # ── Validate workspace IDs ─────────────────────────────────────────────────
    valid_ids = set(workspace_registry.list_ids())
    accepted: list[WorkspaceConfidence] = []
    for ws in output.workspaces:
        if ws.id in valid_ids:
            accepted.append(ws)
        else:
            logger.warning(
                "IntentAgent: LLM returned unknown workspace id %r — dropping.", ws.id
            )

    if not accepted:
        msg = "IntentAgent: no valid workspace IDs after filtering."
        logger.error(msg)
        return {
            "error": msg,
            "workspace_ids": [],
            "is_multi_domain": False,
            "resolved_entities": output.resolved_entities,
            "ambiguities_flagged": output.ambiguities_flagged,
        }

    workspace_ids = [ws.id for ws in accepted]

    logger.info(
        "IntentAgent: workspaces=%s is_multi_domain=%s ambiguities=%s",
        [(ws.id, ws.confidence) for ws in accepted],
        output.is_multi_domain,
        output.ambiguities_flagged,
    )

    return {
        "workspace_ids": workspace_ids,
        "is_multi_domain": output.is_multi_domain,
        "resolved_entities": output.resolved_entities,
        "ambiguities_flagged": output.ambiguities_flagged,
        "error": None,
    }


# ── Factory ────────────────────────────────────────────────────────────────────

def make_intent_agent_node(
    llm: LLMProvider,
    registry: WorkspaceRegistry,
):
    """
    Return a LangGraph-compatible async node function with *llm* and *registry*
    pre-bound via :func:`functools.partial`.

    Usage::

        node_fn = make_intent_agent_node(llm=ollama_provider, registry=WorkspaceRegistry())
        graph.add_node("intent_agent", node_fn)
    """
    return partial(intent_agent_node, llm=llm, workspace_registry=registry)
