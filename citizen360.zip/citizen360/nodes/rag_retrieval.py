"""
citizen360.nodes.rag_retrieval
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
LangGraph node: Retrieves few-shot SQL examples and candidate tables.

Architecture mirrors Student Dropout v1.3.1 mcp_rag.py:
──────────────────────────────────────────────────────────
  1. Embed the question.
  2. Search few_shot_store partition  → fewshot SQL examples
     • Extract bare table names from source_file of each matched fewshot.
     • These tables are ranked FIRST in candidate_tables (highest signal).
  3. Search schema_store partition    → schema DDL hits
     • table_name from each hit goes into candidate_tables.
  4. Deduplicate + apply min-score threshold (0.35, same as Student Dropout).
  5. Merge: fewshot-derived tables first, then schema-derived tables.

Why fewshot tables are ranked first:
  When the user's question semantically matches a gold fewshot, the tables
  that fewshot used are almost certainly the correct ones. This is the key
  insight from Student Dropout that drives Recall@8 well above 90%.

State keys written
------------------
  sql_examples      list[dict]   — [{question, sql, workspace_id}, …]
  candidate_tables  list[str]    — deduplicated table names (fewshot-first)
"""
from __future__ import annotations

import logging
from functools import partial
from typing import Any

PipelineState = dict[str, Any]

from citizen360.plugins.llm.base import LLMProvider
from citizen360.plugins.vector.milvus_lite import MilvusLiteStore
from citizen360.plugins.workspace.registry import WorkspaceRegistry

logger = logging.getLogger(__name__)

# Minimum cosine similarity — same threshold as Student Dropout mcp_rag.py
_MIN_SCORE = 0.35

# Minimum schema hits before falling back to static workspace candidate tables
_MIN_VECTOR_TABLES = 3


def _extract_tables_from_hit(hit: dict) -> list[str]:
    """
    Extract bare table names from a fewshot hit.

    The source_file field is repurposed to store a pipe-separated list of
    bare table names (set by index_examples.py). Falls back to an empty list
    if the field is missing or empty.
    """
    tables_str = hit.get("source_file", "")
    if not tables_str:
        return []
    return [t.strip() for t in tables_str.split("|") if t.strip()]


async def rag_retrieval_node(
    state: PipelineState,
    *,
    llm: LLMProvider,
    vector_store: MilvusLiteStore,
    workspace_registry: WorkspaceRegistry,
    top_k_sql: int = 5,
    top_k_tables: int = 10,
    # Legacy params — kept for backwards compat with make_rag_retrieval_node
    sql_collection: str | None = None,
    tables_collection: str | None = None,
) -> dict:
    """
    Embed *state["raw_question"]* and retrieve candidate tables + SQL examples.

    Retrieval order (mirrors Student Dropout mcp_rag.py):
      A) few_shot_store  → top_k_sql fewshot examples per workspace
         Tables from matched fewshots are prepended to candidate_tables.
      B) schema_store    → top_k_tables schema hits per workspace
         table_name from each hit appended to candidate_tables.
    """
    question: str      = state.get("raw_question", "").strip()
    workspace_ids: list[str] = state.get("workspace_ids", [])

    if not question:
        logger.error("rag_retrieval_node: raw_question is empty.")
        return {"sql_examples": [], "candidate_tables": []}

    if not workspace_ids:
        logger.error("rag_retrieval_node: workspace_ids is empty.")
        return {"sql_examples": [], "candidate_tables": []}

    # ── 1. Embed the question ──────────────────────────────────────────────────
    logger.info("RAGRetrieval: embedding question for %d workspace(s).", len(workspace_ids))
    query_embedding: list[float] = await llm.embed(question)

    # ── 2. Retrieve per workspace ──────────────────────────────────────────────
    all_sql_examples:   list[dict] = []
    seen_tables:        set[str]   = set()
    fewshot_tables:     list[str]  = []   # tables from fewshot hits — ranked first
    schema_tables:      list[str]  = []   # tables from schema hits  — ranked second

    for workspace_id in workspace_ids:

        # A) few_shot_store — NL→SQL exemplars (Student Dropout: few_shot_store partition)
        fewshot_hits = await vector_store.search_fewshots(
            query_embedding=query_embedding,
            top_k=top_k_sql,
            workspace_id=workspace_id,
        )
        # NOTE: No min-score filter for fewshots.
        # FLAT index on small Milvus-Lite partitions returns unreliably low
        # COSINE scores (e.g. 0.02 even for identical strings). We trust
        # rank-order only — top-k is reliable, absolute score is not.

        for hit in fewshot_hits:
            all_sql_examples.append({
                "question":    hit.get("embedding_text", ""),
                "sql":         hit.get("raw_ddl", ""),
                "workspace_id": hit.get("workspace_id", workspace_id),
            })
            # Extract tables and prepend them (fewshot tables ranked first)
            for t in _extract_tables_from_hit(hit):
                if t not in seen_tables:
                    seen_tables.add(t)
                    fewshot_tables.append(t)

        logger.debug(
            "RAGRetrieval: workspace=%s fewshot_hits=%d (after threshold)",
            workspace_id, len(fewshot_hits),
        )

        # B) schema_store — DDL / table descriptions (Student Dropout: schema_store partition)
        schema_hits = await vector_store.search_schema(
            query_embedding=query_embedding,
            top_k=top_k_tables,
            workspace_id=workspace_id,
        )
        # Apply min-score threshold
        schema_hits = [h for h in schema_hits if h.get("score", 0) >= _MIN_SCORE]

        ws_schema_tables: list[str] = []
        for hit in schema_hits:
            tname = hit.get("table_name", "")
            if tname and tname != "__join_relations__":
                ws_schema_tables.append(tname)

        logger.debug(
            "RAGRetrieval: workspace=%s schema_hits=%d tables=%d",
            workspace_id, len(schema_hits), len(ws_schema_tables),
        )

        # Fallback to static candidate tables if vector search is very sparse
        if len(ws_schema_tables) < _MIN_VECTOR_TABLES:
            try:
                static_tables = workspace_registry.get(workspace_id).candidate_tables
            except KeyError:
                static_tables = []
            logger.info(
                "RAGRetrieval: workspace=%s schema returned only %d table(s) "
                "— supplementing with %d static tables.",
                workspace_id, len(ws_schema_tables), len(static_tables),
            )
            for t in static_tables:
                if t not in ws_schema_tables:
                    ws_schema_tables.append(t)

        for t in ws_schema_tables:
            if t not in seen_tables:
                seen_tables.add(t)
                schema_tables.append(t)

    # ── 3. Merge: fewshot tables first (highest signal), then schema tables ───
    # Identical to Student Dropout mcp_rag.py: "Few-shot examples first
    # (highest semantic signal), then schema DDLs"
    all_candidate_tables = fewshot_tables + schema_tables

    logger.info(
        "RAGRetrieval: sql_examples=%d fewshot_tables=%d schema_tables=%d total_candidates=%d",
        len(all_sql_examples),
        len(fewshot_tables),
        len(schema_tables),
        len(all_candidate_tables),
    )

    return {
        "sql_examples":     all_sql_examples,
        "candidate_tables": all_candidate_tables,
    }


# ── Factory ────────────────────────────────────────────────────────────────────

def make_rag_retrieval_node(
    llm: LLMProvider,
    vector_store: MilvusLiteStore,
    workspace_registry: WorkspaceRegistry,
    top_k_sql: int = 5,
    top_k_tables: int = 10,
    sql_collection: str | None = None,
    tables_collection: str | None = None,
):
    """
    Return a LangGraph-compatible async node function with all dependencies
    pre-bound via functools.partial.

    Usage::

        node_fn = make_rag_retrieval_node(
            llm=ollama_provider,
            vector_store=milvus_store,
            workspace_registry=WorkspaceRegistry(),
            top_k_sql=5,
            top_k_tables=10,
        )
        graph.add_node("rag_retrieval", node_fn)
    """
    return partial(
        rag_retrieval_node,
        llm=llm,
        vector_store=vector_store,
        workspace_registry=workspace_registry,
        top_k_sql=top_k_sql,
        top_k_tables=top_k_tables,
    )
